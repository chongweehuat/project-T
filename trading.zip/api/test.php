<?php
file_put_contents("/var/www/api/logs/debug.log",var_export($_POST,1));